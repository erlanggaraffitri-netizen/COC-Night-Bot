# COC Night Bot — Android 15 prototype

Aplikasi pendamping/perencana strategi manual untuk Clash of Clans Builder Base.

## Fitur prototipe
- Pilihan pasukan.
- Pilihan pola serangan.
- Pilihan prioritas target.
- Catatan rencana serangan.
- Ringkasan rencana.

## Batasan
Ini bukan bot auto-play. Aplikasi tidak mengendalikan Clash of Clans,
tidak memakai Accessibility Service untuk menekan layar, tidak membaca
memori/proses game, dan tidak melakukan serangan otomatis. Pemain tetap
menjalankan semua aksi dalam game secara manual.

## Cara membuka dan membuat APK
1. Ekstrak ZIP.
2. Buka folder `COC-Night-Bot-Android15` di Android Studio.
3. Pastikan Android SDK Platform 35 dan JDK 17 tersedia.
4. Tunggu Gradle Sync selesai.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Teknologi
- Kotlin
- Jetpack Compose
- Material 3
- compileSdk 35 / targetSdk 35

Catatan: Versi plugin dan dependensi dapat memerlukan penyesuaian jika
Android Studio/Gradle lokal menggunakan versi yang berbeda.
