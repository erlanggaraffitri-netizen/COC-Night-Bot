package com.example.cocnightbot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NightBotApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NightBotApp() {
    var troop by remember { mutableStateOf("Baby Dragon") }
    var strategy by remember { mutableStateOf("Serangan bertahap") }
    var target by remember { mutableStateOf("Bangunan pertahanan") }
    var notes by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    val troops = listOf("Baby Dragon", "Sneaky Archers", "Boxer Giants",
        "Cannon Carts", "Night Witches", "Power P.E.K.K.A")
    val strategies = listOf("Serangan bertahap", "Fokus satu sisi",
        "Hancurkan pertahanan utama", "Serangan udara")
    val targets = listOf("Bangunan pertahanan", "Builder Hall",
        "Bangunan luar", "Jalur menuju inti desa")

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("COC NIGHT BOT", fontWeight = FontWeight.Bold) },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize()
                    .verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("BUILDER BASE • ANDROID 15",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(8.dp))
                        Text("Perencana serangan manual",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Atur komposisi pasukan dan rencana serangan sebelum bermain.")
                    }
                }

                SectionTitle("1. Pilih pasukan")
                ChoiceDropdown("Pasukan utama", troop, troops) { troop = it }

                SectionTitle("2. Atur strategi")
                ChoiceDropdown("Pola serangan", strategy, strategies) { strategy = it }
                ChoiceDropdown("Prioritas target", target, targets) { target = it }

                SectionTitle("3. Catatan rencana")
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    label = { Text("Contoh: mulai dari sisi kiri, simpan unit...") }
                )

                Button(
                    onClick = { saved = true },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Simpan rencana") }

                if (saved) {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("Rencana tersimpan di layar",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary)
                            Text("Pasukan: $troop")
                            Text("Strategi: $strategy")
                            Text("Prioritas: $target")
                            if (notes.isNotBlank()) Text("Catatan: $notes")
                        }
                    }
                }

                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Catatan penggunaan", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Aplikasi ini adalah alat bantu strategi. Aplikasi tidak membuka, " +
                            "menekan layar, membaca memori game, memilih target, atau " +
                            "menjalankan serangan otomatis di Clash of Clans. " +
                            "Lakukan tindakan permainan secara manual."
                        )
                    }
                }
                Text("COC Night Bot • Prototype 1.0",
                    style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChoiceDropdown(
    label: String,
    selected: String,
    choices: List<String>,
    onSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            choices.forEach { item ->
                DropdownMenuItem(
                    text = { Text(item) },
                    onClick = {
                        onSelected(item)
                        expanded = false
                    }
                )
            }
        }
    }
}
